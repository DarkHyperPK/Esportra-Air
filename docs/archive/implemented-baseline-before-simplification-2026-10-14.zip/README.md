# Esportra Air implemented UI reference

Single active screen reference, generated 14 October 2026. Product brief: [original index.html](../../index.html). Functional coverage: [53-requirement register](../../docs/coverage/INDEX-COVERAGE.md).

79 screenshots cover all 26 A–Z workflow groups. Screens are real current React components with synthetic accounts, API records, OBS status and desktop IPC. Capture-active and relay-connected values demonstrate implemented rendering, not a real game/connection. Producer monitors may be empty because no live OBS screenshots are supplied. No account, credential, clipboard, OBS instance or game is touched. Native fixture evidence from the prior product checks is separate.

Open [index.html](index.html) directly in a browser; no server is required. PNGs under screens/A through screens/Z are full resolution. [screen-register.md](screen-register.md) maps each screenshot to component, fixture URL and viewport. Missing PRD interfaces are listed in coverage rather than fabricated as implemented screenshots. The root index and original linked images remain unchanged.

## Regenerate

From D:/Esportra-Air, run node tools/audit-index-prd.cjs to extract the original requirements; reassess docs/coverage/index-coverage.json when code changes. From D:/frag-and-book-main, run node tools/export-air-uiux.cjs using the existing frontend build CSS. Then from D:/Esportra-Air run node tools/build-uiux-reference.cjs. The exporter needs the installed Playwright/browser and frontend dependencies; it uses the real Air App and isolated helper tools/uiux-desktop-fixture.cjs.

## Journeys

- A: Tournament entry and eligibility
- B: Home and show ledger
- C: Create or select show
- D: Show identity and schedule
- E: Nine preparation steps
- F: Web pairing
- G: Node directory and revocation
- H: On-air talent
- I: Sponsors
- J: Crew management
- K: Invitation acceptance
- L: Assigned crew workspace
- M: Rundown and segment editing
- N: Platform live and end confirmations
- O: Post-show report
- P: Sponsor proof
- Q: VOD chapters
- R: Recorded activity
- S: Desktop machine role
- T: Desktop pairing
- U: Production readiness
- V: Producer and OBS
- W: Observer capture
- X: Browser outputs
- Y: Local score correction
- Z: Offline continuation
