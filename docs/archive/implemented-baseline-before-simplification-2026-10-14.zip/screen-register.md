# A–Z current screen register

Fixture URLs below select capture scenarios; they do not add production routes. Every image is real renderer output with synthetic data.

| ID | Screen | Surface | Component | Fixture path | Image |
| --- | --- | --- | --- | --- | --- |
| A01-tournament-entry | Tournament dashboard · Broadcast | web | BroadcastPanel | /organizer/tournament/spring-invitational?tab=broadcast | [PNG](screens/A/A01-tournament-entry.png) |
| A02-organization-required | Link an owned organization | web | BroadcastPanel | /organizer/tournament/spring-invitational?tab=broadcast&scenario=unassigned | [PNG](screens/A/A02-organization-required.png) |
| A03-owner-required | Organization-owner access required | web | BroadcastPanel | /organizer/tournament/spring-invitational?tab=broadcast&scenario=blocked | [PNG](screens/A/A03-owner-required.png) |
| B01-shows | Organization show ledger | web | BroadcastShowsPage | /broadcast/shows | [PNG](screens/B/B01-shows.png) |
| B02-empty-shows | No shows yet | web | BroadcastShowsPage | /broadcast/shows?scenario=empty | [PNG](screens/B/B02-empty-shows.png) |
| C01-get-started | Create or select a show | web | BroadcastGetStartedPage | /broadcast/get-started | [PNG](screens/C/C01-get-started.png) |
| C02-create-show | Create show form | web | BroadcastShowsPage | /broadcast/shows | [PNG](screens/C/C02-create-show.png) |
| D01-show-settings | Identity, tournament and planned start | web | ShowSettingsDialog | /broadcast/get-started?showId=5e182c34-49f8-40d3-bf6c-88b576c20c45&step=0 | [PNG](screens/D/D01-show-settings.png) |
| E01-preparation | Show identity | web | ShowPreparation / PreparationStepContent | /broadcast/get-started?showId=5e182c34-49f8-40d3-bf6c-88b576c20c45&step=0 | [PNG](screens/E/E01-preparation.png) |
| E02-preparation | Tournament | web | ShowPreparation / PreparationStepContent | /broadcast/get-started?showId=5e182c34-49f8-40d3-bf6c-88b576c20c45&step=1 | [PNG](screens/E/E02-preparation.png) |
| E03-preparation | Matches and codes | web | ShowPreparation / PreparationStepContent | /broadcast/get-started?showId=5e182c34-49f8-40d3-bf6c-88b576c20c45&step=2 | [PNG](screens/E/E03-preparation.png) |
| E04-preparation | Desktop nodes | web | ShowPreparation / PreparationStepContent | /broadcast/get-started?showId=5e182c34-49f8-40d3-bf6c-88b576c20c45&step=3 | [PNG](screens/E/E04-preparation.png) |
| E05-preparation | Crew | web | ShowPreparation / PreparationStepContent | /broadcast/get-started?showId=5e182c34-49f8-40d3-bf6c-88b576c20c45&step=4 | [PNG](screens/E/E05-preparation.png) |
| E06-preparation | On-air talent | web | ShowPreparation / PreparationStepContent | /broadcast/get-started?showId=5e182c34-49f8-40d3-bf6c-88b576c20c45&step=5 | [PNG](screens/E/E06-preparation.png) |
| E07-preparation | Sponsors | web | ShowPreparation / PreparationStepContent | /broadcast/get-started?showId=5e182c34-49f8-40d3-bf6c-88b576c20c45&step=6 | [PNG](screens/E/E07-preparation.png) |
| E08-preparation | Rundown | web | ShowPreparation / PreparationStepContent | /broadcast/get-started?showId=5e182c34-49f8-40d3-bf6c-88b576c20c45&step=7 | [PNG](screens/E/E08-preparation.png) |
| E09-preparation | Send to desktop | web | ShowPreparation / PreparationStepContent | /broadcast/get-started?showId=5e182c34-49f8-40d3-bf6c-88b576c20c45&step=8 | [PNG](screens/E/E09-preparation.png) |
| F01-pair-dialog | Generate a temporary pairing code | web | PairNodeDialog | /broadcast/home | [PNG](screens/F/F01-pair-dialog.png) |
| F02-pair-code | Pairing code and countdown | web | PairNodeDialog | /broadcast/home | [PNG](screens/F/F02-pair-code.png) |
| F03-pair-expired | Expired code recovery | web | PairNodeDialog | /broadcast/home?scenario=expired | [PNG](screens/F/F03-pair-expired.png) |
| G01-node-directory | Registered nodes and heartbeat | web | BroadcastNodeMonitorPage | /broadcast/shows/5e182c34-49f8-40d3-bf6c-88b576c20c45/nodes | [PNG](screens/G/G01-node-directory.png) |
| G02-revoke-node | Confirm node access revocation | web | NodeCard | /broadcast/shows/5e182c34-49f8-40d3-bf6c-88b576c20c45/nodes | [PNG](screens/G/G02-revoke-node.png) |
| G03-no-nodes | No paired nodes | web | BroadcastNodeMonitorPage | /broadcast/shows/5e182c34-49f8-40d3-bf6c-88b576c20c45/nodes?scenario=empty | [PNG](screens/G/G03-no-nodes.png) |
| H01-talent | On-air talent roster and add form | web | TalentRoster | /broadcast/get-started?showId=5e182c34-49f8-40d3-bf6c-88b576c20c45&step=5 | [PNG](screens/H/H01-talent.png) |
| I01-sponsors | Show sponsor directory | web | BroadcastSponsorsPage | /broadcast/shows/5e182c34-49f8-40d3-bf6c-88b576c20c45/sponsors | [PNG](screens/I/I01-sponsors.png) |
| I02-add-sponsor | Sponsor settings form | web | BroadcastSponsorsPage | /broadcast/shows/5e182c34-49f8-40d3-bf6c-88b576c20c45/sponsors | [PNG](screens/I/I02-add-sponsor.png) |
| J01-crew | Crew roles and pending invites | web | BroadcastCrewPage | /broadcast/shows/5e182c34-49f8-40d3-bf6c-88b576c20c45/crew | [PNG](screens/J/J01-crew.png) |
| J02-invite-link | Single-use role invitation | web | BroadcastCrewPage | /broadcast/shows/5e182c34-49f8-40d3-bf6c-88b576c20c45/crew | [PNG](screens/J/J02-invite-link.png) |
| J03-revoke-invite | Confirm invite revocation | web | BroadcastCrewPage | /broadcast/shows/5e182c34-49f8-40d3-bf6c-88b576c20c45/crew | [PNG](screens/J/J03-revoke-invite.png) |
| J04-remove-crew | Confirm crew removal | web | BroadcastCrewPage | /broadcast/shows/5e182c34-49f8-40d3-bf6c-88b576c20c45/crew | [PNG](screens/J/J04-remove-crew.png) |
| K01-join-missing | Missing invitation token | web | BroadcastCrewJoinPage | /broadcast/join | [PNG](screens/K/K01-join-missing.png) |
| K02-join-ready | Accept a crew invitation | web | BroadcastCrewJoinPage | /broadcast/join | [PNG](screens/K/K02-join-ready.png) |
| K03-join-accepted | Invitation accepted | web | BroadcastCrewJoinPage | /broadcast/join | [PNG](screens/K/K03-join-accepted.png) |
| K04-join-expired | Expired or used invitation | web | BroadcastCrewJoinPage | /broadcast/join?scenario=expired | [PNG](screens/K/K04-join-expired.png) |
| L01-crew-shows | Assigned crew show list | web | BroadcastCrewWorkspacePage | /broadcast/crew/shows | [PNG](screens/L/L01-crew-shows.png) |
| L02-crew-brief | Observer role brief, match codes and plan | web | BroadcastCrewWorkspacePage | /broadcast/crew/shows/5e182c34-49f8-40d3-bf6c-88b576c20c45 | [PNG](screens/L/L02-crew-brief.png) |
| M01-rundown | Show workspace and rundown | web | BroadcastShowDetailPage | /broadcast/shows/5e182c34-49f8-40d3-bf6c-88b576c20c45 | [PNG](screens/M/M01-rundown.png) |
| M02-segment-expanded | Expanded rundown segment | web | RundownRow | /broadcast/shows/5e182c34-49f8-40d3-bf6c-88b576c20c45 | [PNG](screens/M/M02-segment-expanded.png) |
| N01-mark-live | Confirm platform live status | web | BroadcastShowDetailPage | /broadcast/shows/5e182c34-49f8-40d3-bf6c-88b576c20c45 | [PNG](screens/N/N01-mark-live.png) |
| N02-end-show | Confirm platform show end | web | BroadcastShowDetailPage | /broadcast/shows/5e182c34-49f8-40d3-bf6c-88b576c20c45?scenario=live | [PNG](screens/N/N02-end-show.png) |
| O01-report | Post-show recorded report | web | BroadcastPostShowReportPage | /broadcast/shows/5e182c34-49f8-40d3-bf6c-88b576c20c45/report?scenario=ended | [PNG](screens/O/O01-report.png) |
| O02-report-not-ended | Report waits for show end | web | BroadcastPostShowReportPage | /broadcast/shows/5e182c34-49f8-40d3-bf6c-88b576c20c45/report?scenario=live | [PNG](screens/O/O02-report-not-ended.png) |
| P01-sponsor-proof | Recorded sponsor time and proof export | web | BroadcastSponsorProofPage | /broadcast/shows/5e182c34-49f8-40d3-bf6c-88b576c20c45/sponsor-proof?scenario=ended | [PNG](screens/P/P01-sponsor-proof.png) |
| P02-proof-empty | No sponsor impressions yet | web | BroadcastSponsorProofPage | /broadcast/shows/5e182c34-49f8-40d3-bf6c-88b576c20c45/sponsor-proof?scenario=empty | [PNG](screens/P/P02-proof-empty.png) |
| Q01-vod-chapters | VOD chapters and YouTube copy | web | BroadcastVodChaptersPage | /broadcast/shows/5e182c34-49f8-40d3-bf6c-88b576c20c45/vod-chapters?scenario=ended | [PNG](screens/Q/Q01-vod-chapters.png) |
| Q02-vod-empty | No recorded chapters | web | BroadcastVodChaptersPage | /broadcast/shows/5e182c34-49f8-40d3-bf6c-88b576c20c45/vod-chapters?scenario=empty | [PNG](screens/Q/Q02-vod-empty.png) |
| R01-activity | Recorded production activity | web | BroadcastActivityPage | /broadcast/shows/5e182c34-49f8-40d3-bf6c-88b576c20c45/activity | [PNG](screens/R/R01-activity.png) |
| R02-activity-older | Activity pagination | web | BroadcastActivityPage | /broadcast/shows/5e182c34-49f8-40d3-bf6c-88b576c20c45/activity | [PNG](screens/R/R02-activity-older.png) |
| S01-machine-role | Production or observer machine role | desktop renderer | ModeScreen | /desktop?screen=mode | [PNG](screens/S/S01-machine-role.png) |
| S02-restart-role | Restart required after role selection | desktop renderer | ModeScreen | /desktop?screen=mode | [PNG](screens/S/S02-restart-role.png) |
| T01-desktop-pair | Desktop pairing form | desktop renderer | PairScreen | /desktop?screen=pair | [PNG](screens/T/T01-desktop-pair.png) |
| T02-pair-error | Invalid or expired pairing code | desktop renderer | PairScreen | /desktop?screen=pair-error | [PNG](screens/T/T02-pair-error.png) |
| U01-readiness | Production desk readiness | desktop renderer | ProductionReadiness | /desktop?screen=readiness | [PNG](screens/U/U01-readiness.png) |
| U02-no-show | Awaiting a show configuration | desktop renderer | ProductionReadiness | /desktop?screen=no-show | [PNG](screens/U/U02-no-show.png) |
| U03-pending-plan | Waiting plan and explicit apply | desktop renderer | ProductionReadiness | /desktop?screen=pending | [PNG](screens/U/U03-pending-plan.png) |
| U04-stop-rundown | Stop local rundown confirmation | desktop renderer | ProductionReadiness | /desktop?screen=stop | [PNG](screens/U/U04-stop-rundown.png) |
| V01-obs-disconnected | Producer console before OBS connection | desktop renderer | ProducerScreen | /desktop?screen=producer | [PNG](screens/V/V01-obs-disconnected.png) |
| V02-armed | Producer · armed | desktop renderer | ProducerScreen | /desktop?screen=producer-armed | [PNG](screens/V/V02-armed.png) |
| V03-holding | Producer · holding | desktop renderer | ProducerScreen | /desktop?screen=producer-holding | [PNG](screens/V/V03-holding.png) |
| V04-live | Producer · live | desktop renderer | ProducerScreen | /desktop?screen=producer-live | [PNG](screens/V/V04-live.png) |
| V05-paused | Producer · paused | desktop renderer | ProducerScreen | /desktop?screen=producer-paused | [PNG](screens/V/V05-paused.png) |
| V06-scenes-prepared | OBS scene preparation feedback | desktop renderer | ProducerScreen | /desktop?screen=producer-paused | [PNG](screens/V/V06-scenes-prepared.png) |
| W01-observer | Observer capture utility · waiting for production | desktop renderer | CaptureScreen | /desktop?screen=capture | [PNG](screens/W/W01-observer.png) |
| W02-capture-consent | Capture privacy consent | desktop renderer | CaptureControls | /desktop?screen=capture | [PNG](screens/W/W02-capture-consent.png) |
| W03-capture-active | Capture process active · fixture packet rate | desktop renderer | CaptureScreen | /desktop?screen=capture-active | [PNG](screens/W/W03-capture-active.png) |
| W04-relay-connected | LAN consumer connected | desktop renderer | CaptureScreen | /desktop?screen=capture-connected | [PNG](screens/W/W04-relay-connected.png) |
| X01-outputs-empty | First browser source | desktop renderer | SourceOutputs | /desktop?screen=readiness | [PNG](screens/X/X01-outputs-empty.png) |
| X02-output-form | Add existing HUD overlay output | desktop renderer | SourceOutputs | /desktop?screen=readiness | [PNG](screens/X/X02-output-form.png) |
| X03-output-list | Local HTTP browser source inventory | desktop renderer | SourceOutputs | /desktop?screen=outputs-list | [PNG](screens/X/X03-output-list.png) |
| X04-output-lan | LAN browser source address | desktop renderer | SourceOutputs | /desktop?screen=outputs-list | [PNG](screens/X/X04-output-lan.png) |
| X05-remove-output | Remove browser output confirmation | desktop renderer | SourceOutputs | /desktop?screen=outputs-list | [PNG](screens/X/X05-remove-output.png) |
| Y01-score-form | Review a local map correction | desktop renderer | ScoreCorrection | /desktop?screen=readiness | [PNG](screens/Y/Y01-score-form.png) |
| Y02-score-confirm | Confirm local HUD correction | desktop renderer | ScoreCorrection | /desktop?screen=readiness | [PNG](screens/Y/Y02-score-confirm.png) |
| Z01-offline | Platform disconnected · local systems and queued records | desktop renderer | ProductionReadiness | /desktop?screen=offline | [PNG](screens/Z/Z01-offline.png) |
| A04-tournament-phone | Tournament Broadcast on a phone | phone web | Current web page at phone viewport | /organizer/tournament/spring-invitational?tab=broadcast | [PNG](screens/A/A04-tournament-phone.png) |
| B03-home-phone | Broadcast home on a phone | phone web | Current web page at phone viewport | /broadcast/home | [PNG](screens/B/B03-home-phone.png) |
| E10-preparation-phone | Preparation step selector on a phone | phone web | Current web page at phone viewport | /broadcast/get-started?showId=5e182c34-49f8-40d3-bf6c-88b576c20c45&step=3 | [PNG](screens/E/E10-preparation-phone.png) |
| M03-rundown-phone | Rundown on a phone | phone web | Current web page at phone viewport | /broadcast/shows/5e182c34-49f8-40d3-bf6c-88b576c20c45 | [PNG](screens/M/M03-rundown-phone.png) |
| O03-report-phone | Post-show report on a phone | phone web | Current web page at phone viewport | /broadcast/shows/5e182c34-49f8-40d3-bf6c-88b576c20c45/report | [PNG](screens/O/O03-report-phone.png) |
