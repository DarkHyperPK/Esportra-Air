const tag = (label, tone='') => `<span class="tag ${tone}"><i class="dot"></i>${label}</span>`;
const button = (label, kind='', attributes='') => `<button type="button" class="${kind}" ${attributes}>${label}</button>`;
const gap = '<div class="gap"></div>';
const primary = label => button(label,'primary');
const panel = (title, body, aside='') => `<section class="panel"><div class="panel-head"><h2>${title}</h2>${aside}</div><div class="panel-body">${body}</div></section>`;
const intro = (title, text, action='', breadcrumb='') => `<div class="page-head">${breadcrumb?`<div class="breadcrumb">${breadcrumb}</div>`:''}<div class="between"><div><h1>${title}</h1><p>${text}</p></div>${action}</div></div>`;
const field = (label, value, help='', select=false) => `<div class="field"><label>${label}</label><div class="input">${value}${select?'<span class="muted">⌄</span>':''}</div>${help?`<div class="hint">${help}</div>`:''}</div>`;
const note = (title, text, tone='') => `<div class="notice ${tone}"><strong>${title}</strong>${text}</div>`;
const metric = (title, value, text) => `<div class="metric"><span class="caption">${title}</span><strong>${value}</strong><p>${text}</p></div>`;
const stats = items => `<div class="metric-strip">${items.join('')}</div>`;
const table = (headers, rows, widths=[]) => `<table class="table"><colgroup>${headers.map((_,i)=>`<col style="width:${widths[i]||'auto'}">`).join('')}</colgroup><thead><tr>${headers.map(h=>`<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.map(row=>`<tr>${row.map(cell=>`<td>${cell}</td>`).join('')}</tr>`).join('')}</tbody></table>`;
const health = (label, detail, state, tone='green') => `<div class="health"><div class="health-name"><i class="dot ${tone}"></i><div><strong>${label}</strong><p>${detail}</p></div></div><span class="mono ${tone}">${state}</span></div>`;
const preview = (name='ingame') => `<div class="preview"><img src="assets/${name}.jpg" alt="Existing Esportra overlay artwork used as a design fixture"></div>`;
const person = (name, detail, initials) => `<div class="identity"><div class="avatar">${initials}</div><div><strong>${name}</strong><div class="tiny muted">${detail}</div></div></div>`;
const tabs = (items, active) => `<div class="tabs">${items.map(i=>`<span class="tab ${i===active?'active':''}">${i}</span>`).join('')}</div>`;
const showTabs = active => tabs(['Rundown','Setup','Nodes','Crew','Sponsors','Reports'],active);
const footer = text => `<div class="footer-note"><span>${text}</span><span>PROJ-061 · Illustrative design data</span></div>`;
const webNav = [['⌂','Home'],['▤','Shows'],['▣','Production nodes'],['☑','Get started']];
const desktopNav = [['◈','Readiness'],['▣','Producer'],['↗','Outputs']];

function shell(body, active='Home', mode='web') {
  const desktop = mode !== 'web';
  const nodeLabel = mode==='capture'?'Observer PC · Capture-only':'Studio PC · Production';
  const nav = desktop ? (mode==='capture'?[['⌁','Capture']]:desktopNav) : webNav;
  const navMarkup = nav.map(([icon,name])=>`<div class="navitem ${name===active?'active':''}"><span class="icon" aria-hidden="true">${icon}</span>${name}</div>`).join('');
  const top = desktop ? `<div class="topbar"><div class="flex"><div class="brand"><img src="assets/mark-44.png" alt="Esportra">Esportra Air</div><span class="muted">/ ${nodeLabel}</span></div><div class="window-actions">− &nbsp; □ &nbsp; ×</div></div>` : `<div class="topbar"><div class="flex"><div class="brand"><img src="assets/mark-44.png" alt="Esportra">esportra<span>Air</span></div><div class="topnav"><span>Tournaments</span><span>Teams</span><span class="selected">Broadcast</span></div></div><div class="flex top-organization"><span class="smalltext muted">Arena production</span><span class="divider-v"></span><span class="avatar">AP</span></div></div>`;
  const bottom = desktop ? `<strong class="smalltext">${nodeLabel}</strong><p class="tiny">${mode==='capture'?'Game data over LAN':'Local production node'}</p>` : '<strong class="smalltext">Arena production</strong><p class="tiny">Organization owner</p>';
  return `${top}<div class="main-grid"><aside class="sidebar"><div class="caption">${desktop?'This computer':'Broadcast workspace'}</div>${navMarkup}<div class="sidebar-bottom">${bottom}<div class="gap-sm"></div><span class="tiny muted">${desktop?'Node settings':'Workspace settings'}</span></div></aside><main class="workspace">${body}${desktop?`<div class="statusbar"><span>${mode==='capture'?'Capture-only · Observer PC':'HUD server · 127.0.0.1:5300'}</span><span>Design fixture · 19:42 PKT</span></div>`:''}</main></div>`;
}

function modal(base, title, text, body, actions, size='') {
  return `${base}<div class="scrim"></div><section class="dialog ${size}"><div class="dialog-head"><div><h2>${title}</h2><p>${text}</p></div><span class="muted" aria-label="Close dialog">×</span></div><div class="dialog-body">${body}</div><div class="dialog-actions">${actions}</div></section>`;
}

function pairingPanel(state='active') {
  const views = {
    active:`<div class="between"><span class="caption">Pairing code</span><span class="mono amber">Expires in 08:42</span></div><div class="pairing-code">QK74 <span>8D3M</span></div><p class="smalltext">Enter this code in Esportra Air on your production PC.</p>${gap}<div class="pair-instructions"><div><b>1</b><span>Open Esportra Air on the production PC.</span></div><div><b>2</b><span>In “Pair this node”, enter all 8 characters.</span></div><div><b>3</b><span>Choose Pair. Return here to check the node list.</span></div></div>${gap}<div class="between"><span class="smalltext muted">Waiting for a node to connect…</span>${button('Cancel','ghost small')}</div>`,
    expired:`<span class="caption amber">Pairing code expired</span><div class="pairing-code expired">QK74 <span>8D3M</span></div>${note('Generate a new code','This code can no longer be used. Enter the replacement in the desktop app.')} ${gap}${primary('Generate new code')}`,
    connected:`<span class="caption green">Node detected</span><h2 class="green" style="margin-top:16px">Booth B is registered.</h2><p style="margin-top:8px">Check that Booth B is the computer you just paired. Last seen 4 seconds ago.</p>${gap}<div class="strip"><span class="mono">Booth B</span>${tag('Online','green')}</div>${gap}${primary('Continue setup')}`,
    error:`${note('Could not generate a code','Check your connection, then try again.','error')}${gap}${button('Try again')}`,
    generating:'<div class="loading-code"><div class="skeleton short"></div><p>Generating a code…</p></div>'
  };
  return `<div class="pairing-panel">${views[state]}</div>`;
}

const WIZARD_STEPS = ['Link a tournament','Prepare the rundown','Install Esportra Air','Pair the PC','Connect OBS','Build the scenes','Set up capture','Check local graphics','Invite crew'];
function wizardRail(current, completed=[]) {
  return `<aside class="wizard-rail"><span class="caption">First show setup</span><ol>${WIZARD_STEPS.map((name,i)=>`<li class="${i===current?'current':''} ${completed.includes(i)?'done':''}"><span>${completed.includes(i)?'✓':i+1}</span><div>${name}<small>${completed.includes(i)?'Preparation complete':i===current?'Current step':'Not completed'}</small></div></li>`).join('')}</ol></aside>`;
}
