const mobileNav = selected => `<nav class="mobile-nav"><span class="${selected==='Home'?'selected':''}">Home</span><span class="${selected==='Shows'?'selected':''}">Shows</span><span class="${selected==='Nodes'?'selected':''}">Nodes</span><span class="${selected==='Setup'?'selected':''}">Setup</span></nav>`;

function mobileHome() {
  const items = [metric('Live now','1',''),metric('Queued','2',''),metric('Nodes','2 / 3',''),metric('Hands-free','—',''),metric('Sponsor','—','')];
  return shell(`${intro('Tonight’s shows','13 October 2026 · Pakistan Standard Time')}${stats(items)}<div class="live-card"><div class="between"><h3>Esportra Invitational</h3>${tag('Live','live')}</div><p class="smalltext" style="margin-top:8px">Grand final · Show marked live</p><div class="live-footer"><p class="tiny">Preview and live game details stay on the production PC.</p>${button('Open show','primary')}</div></div>${gap}${panel('Up next','<div class="row"><strong class="smalltext">Karachi Open · Upper semi-final</strong><div class="between" style="margin-top:10px"><span class="mono muted">20:30 PKT</span>'+tag('Scheduled','amber')+'</div></div><div class="row"><strong class="smalltext">Karachi Open · Lower bracket</strong><div class="between" style="margin-top:10px"><span class="mono muted">21:30 PKT</span>'+tag('Draft')+'</div></div>')}${gap}${panel('Production nodes','<div class="row between"><div><strong class="smalltext">Studio PC</strong><p class="tiny">Last seen 4 sec ago</p></div>'+tag('Online','green')+'</div><div class="row between"><div><strong class="smalltext">Observer PC</strong><p class="tiny">Last seen 6 sec ago</p></div>'+tag('Online','green')+'</div><div class="row between"><div><strong class="smalltext">Venue PC</strong><p class="tiny">Last seen 6 min ago</p></div>'+tag('Offline','amber')+'</div>')}${gap}<p class="tiny">Hands-free and sponsor metrics are not available yet.</p>${gap}${button('+ New show','primary','style="width:100%"')}${footer('Illustrative design data')}`)+mobileNav('Home');
}

function mobilePair() {
  return shell(`${intro('Pair your production PC','Step 4 of 9 · Karachi Open')}<div class="panel panel-pad"><div class="between"><strong class="mono">3 / 9</strong><span class="tiny muted">Preparation steps complete</span></div><div class="progress"><div style="width:33%;background:white"></div></div></div>${gap}${pairingPanel('active')}${gap}${note('Pair in the desktop app','The web generates the code. Air on your production PC redeems it.')} ${gap}${button('Refresh node list','','style="width:100%"')}<div class="gap-sm"></div>${button('Continue','primary','disabled style="width:100%"')}<p class="tiny" style="margin-top:10px">Continue after checking that the correct computer has appeared.</p>${footer('Illustrative code only')}`,'Get started')+mobileNav('Setup');
}

function mobileTournament() {
  const base = shell(`${intro('Show setup','Esportra Invitational',tag('Draft'),'Broadcast / Shows')}${panel('Show details','<h3>Esportra Invitational · Grand final</h3><p class="smalltext" style="margin-top:10px">Tournament not linked</p>')}${gap}${panel('Required next step','<h3>Link your organization’s tournament.</h3><p class="smalltext" style="margin-top:10px">Then add match slots to the rundown.</p>')}${footer('Organization-owned tournaments only')}`,'Shows');
  return modal(base,'Link a tournament','Select a tournament owned by this organization.',tournamentContent(),button('Cancel','ghost')+primary('Link Karachi Open 2026'));
}

const SCREENS = [
  {id:'web-01-home',name:'Tonight’s shows',type:'web',render:webHome,summary:'Real show data, heartbeat health and explicit unavailable metrics.'},
  {id:'web-02-node-pairing',name:'Generate a pairing code',type:'web',render:()=>webNodes('active'),summary:'Web generates; desktop redeems. No reversed code-entry flow.'},
  {id:'web-03-pair-expired',name:'Pairing code expired',type:'web',render:()=>webNodes('expired'),summary:'Recover without a dead documentation link or a reusable expired code.'},
  {id:'web-04-node-detected',name:'Node detected',type:'web',render:()=>webNodes('connected'),summary:'Check the newly seen node name; do not claim code-specific confirmation.'},
  {id:'web-05-show-setup',name:'Actionable show setup',type:'web',render:showSetup,summary:'Saved-data completion and inline title / tournament actions.'},
  {id:'web-06-tournament-picker',name:'Link an organization tournament',type:'web',render:tournamentDialog,summary:'Search within the organization; match-slot creation remains separate.'},
  {id:'web-07-title-edit',name:'Edit show title',type:'web',render:()=>titleDialog(false),summary:'Proposed inline save flow for the missing PATCH operation.'},
  {id:'web-08-title-live-lock',name:'Live-title locked state',type:'web',render:()=>titleDialog(true),summary:'Proposed 409 behavior: explain the lock and preserve context.'},
  {id:'web-09-onboarding-first',name:'Onboarding · First step',type:'web',render:onboardingFirst,summary:'Dedicated nine-step flow with creation and organization linking.'},
  {id:'web-09a-onboarding-rundown',name:'Onboarding · Prepare rundown',type:'web',render:()=>onboardingTask(1),summary:'Prepare existing match slots, codes and segments; no editor redesign.'},
  {id:'web-09b-onboarding-install',name:'Onboarding · Install Air',type:'web',render:()=>onboardingTask(2),summary:'No unverified installer link, package size or download-completion claim.'},
  {id:'web-10-onboarding-pair',name:'Onboarding · Pair the PC',type:'web',render:()=>onboardingPair('active'),summary:'Code display is embedded in step four; tokens stay on desktop.'},
  {id:'web-11-onboarding-node',name:'Onboarding · Confirm the node',type:'web',render:()=>onboardingPair('connected'),summary:'Owner checks the registered computer before continuing.'},
  {id:'web-11a-onboarding-obs',name:'Onboarding · Connect OBS',type:'web',render:()=>onboardingTask(4),summary:'Explicit local host and port; password stays in Air.'},
  {id:'web-11b-onboarding-scenes',name:'Onboarding · Check scenes',type:'web',render:()=>onboardingTask(5),summary:'Local scene builder semantics and inspection of preserved scenes.'},
  {id:'web-11c-onboarding-capture',name:'Onboarding · Set up capture',type:'web',render:()=>onboardingTask(6),summary:'Same-PC or separate capture-only observer and LAN game data.'},
  {id:'web-11d-onboarding-graphics',name:'Onboarding · Check graphics',type:'web',render:()=>onboardingTask(7),summary:'Manual source verification; no production simulation promise.'},
  {id:'web-11e-onboarding-invite',name:'Onboarding · Invite crew',type:'web',render:onboardingInvite,summary:'Role first, temporary invitation second, membership after acceptance.'},
  {id:'web-12-onboarding-complete',name:'Preparation complete',type:'web',render:onboardingDone,summary:'Preparation progress is distinct from current local production readiness.'},
  {id:'web-13-crew',name:'Crew roles and visibility',type:'web',render:crewPage,summary:'Five actual role IDs; owner administration and truthful membership states.'},
  {id:'web-14-invite-role',name:'Choose the invitation role',type:'web',render:()=>inviteDialog(false),summary:'Select the supported role before generating the invitation.'},
  {id:'web-15-invite-ready',name:'Temporary invitation ready',type:'web',render:()=>inviteDialog(true),summary:'One-time link, 72-hour expiry, no automatic email or source pack.'},
  {id:'desktop-01-pair',name:'Desktop · Redeem the code',type:'desktop',render:desktopPair,summary:'Counterpart of the web panel; separate registration and connection.'},
  {id:'desktop-02-readiness',name:'Desktop · Local readiness',type:'desktop',render:desktopReadiness,summary:'Production node checks the local server, capture and OBS.'},
  {id:'desktop-03-producer',name:'Desktop · Producer',type:'desktop',render:()=>desktopProducer(true),summary:'Real scene shortcuts, local OBS frames and configured runner hold.'},
  {id:'desktop-04-no-signal',name:'Desktop · OBS disconnected',type:'desktop',render:()=>desktopProducer(false),summary:'No-signal state and unavailable local switching actions.'},
  {id:'desktop-05-capture',name:'Desktop · Capture-only observer',type:'desktop',render:desktopCapture,summary:'Separate observer mode; game events over LAN, no producer navigation.'},
  {id:'desktop-06-outputs',name:'Desktop · Output empty state',type:'desktop',render:desktopOutputs,summary:'Local source setup without invented URLs or populated API records.'},
  {id:'system-01-architecture',name:'System and pairing boundaries',type:'system',render:systemMap,summary:'Platform, production computer, observer child and OBS responsibilities.'},
  {id:'system-02-states',name:'Failure and permission states',type:'system',render:stateBoard,summary:'Expiry, absence, disconnection, authorization and retry states.'},
  {id:'mobile-01-home',name:'Mobile web · Home',type:'mobile',render:mobileHome,summary:'Responsive oversight with honest missing telemetry.'},
  {id:'mobile-02-pair',name:'Mobile web · Pairing step',type:'mobile',render:mobilePair,summary:'Readable code, explicit direction and confirmable node identity.'},
  {id:'mobile-03-tournament',name:'Mobile web · Tournament picker',type:'mobile',render:mobileTournament,summary:'Recomposed dialog with a visible selected organization tournament.'}
];
window.AIR_SCREENS = SCREENS;
const selectedId = new URLSearchParams(location.search).get('screen') || SCREENS[0].id;
const screen = SCREENS.find(s=>s.id===selectedId)||SCREENS[0];
document.body.className = screen.type;
document.body.dataset.screen = screen.id;
document.title = `PROJ-061 — ${screen.name} (static design)`;
document.getElementById('app').innerHTML = screen.render();
