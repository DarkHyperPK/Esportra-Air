# PROJ-061 — CTO source audit for static UI / UX

Date: 2026-10-13. Status: HANDOFF. Independent read-only CTO specialist. Coordinator saved this handoff. No runtime, live environment or deployment verification claimed.

## Understanding

Revise static screens using current system boundaries; do not promise unimplemented telemetry, pairing confirmation or role permissions. Existing executive analysis is reused, not rerun. User authorized context retrieval and screen design; runtime implementation remains behind the proposal gate.

## Verified findings and design implications

1. `BroadcastShowEndpoints.cs:118` exposes titles, status and schedule. Counts are derivable. A live show record does not prove OBS is streaming. Tournament names require the proposed JOIN fix.
2. `BroadcastNodeEndpoints.cs:151` returns ID/name/capabilities/lastSeenAt/isActive. Frontend `broadcast.ts:48` additionally declares mode/HUD/GEP fields that the response omits. `BroadcastHub.cs:112` updates last_seen_at only; `hub-client.js:181` confirms extra heartbeat fields are ignored. Web designs show heartbeat freshness, not local OBS/GEP/runner telemetry.
3. Local OBS frames (`Air/src/main.js:252`), desktop health (`:535`) and runner state (`show-runner.js:226`) have no current web transport. No live-score contract for the proposed home endpoint was found. Scene-take latency (`obs-controller.js:301`) is not game-feed latency. Home metrics excluded by clarification use “—”; alerts use an empty state.
4. Web generates pairing codes (`BroadcastNodeEndpoints.cs:47`); desktop redeems and stores the credential in OS keychain (`Air/src/main.js:489`). The claim transaction records the node privately (`BroadcastNodeEndpoints.cs:81`). There is no code-correlated web claim status/event; node registration precedes hub connectivity. New-node detection must not be presented as proof that this code was redeemed.
5. Invite roles are producer, observer, monitor, technical_director and replay_operator (`BroadcastCrewEndpoints.cs:11`). Owner-only crew listing is at `:187`; all active roles join the same show group (`BroadcastHub.cs:292`). Role names do not imply role-specific remote controls. Result submission uses separate can_submit_result (`DesktopBroadcastEndpoints.cs:801`, migration 20261011100003).
6. Frontend `useBroadcastNodes.ts:20` requests a node-command route that is absent from the current backend; Air main has no matching inbound handler. No fabricated remote commands in the new home/crew mockups.
7. Nine current persisted-data checklist steps are in `useBroadcastSetupStatus.ts:20`. Proposed onboarding is a separate preparation flow, not a claim of measured readiness. OBS connection requires host/port/password (`Air/src/main.js:608`); no auto-discovery. Scene builder is real local IPC (`:649`) and skips existing names (`obs-controller.js:252`). Recorded simulator is development-only (`main.js:859`); mode changes restart (`:56`). Runner default hold is 30 seconds (`show-runner.js:18`); OBS reconnect resumes only a disconnect-caused pause (`:84`).
8. General title/tournament PATCH is absent in current endpoint map (`BroadcastShowEndpoints.cs:28`). Editing and live-title 409 are proposed PROJ-061 behavior. Organization tournaments can use existing `/api/organizations/{orgId}/tournaments` (`OrganizationEndpoints.cs:712`); `/api/tournaments` lacks orgId filtering (`TournamentEndpoints.cs:239`). Config push marks lastSyncedAt after sending, not acknowledgment (`BroadcastShowEndpoints.cs:248`).

## Recommendations applied

Keep the new home honest about unavailable preview/score/metrics. Use web code display and desktop input, refreshable node list and explicit identity confirmation. Use the actual five role IDs and Joined/Invited membership states. Replace excluded look selection with a link to existing rundown preparation and unsupported recorded rehearsal with manual local graphics checks. Show local capture-only navigation separately. Distinguish current capabilities, proposed features and exclusions in the screen-to-evidence matrix.

No blocking question prevents static design; unavailable capabilities can be omitted. Do not turn these source findings into claims that runtime flows pass QA.

Context: current role/profile and repo guidance, focused codex-design-context.md, proposal, clarifications, creative contract, source endpoint/hook/desktop modules and coordinator Obsidian briefing. No vault writes or subdelegation. Suggested memory updates: web DTO drift/local telemetry; uncorrelated pairing detection; real role IDs/permission boundaries; pending PATCH/command APIs; scene builder and development-only simulator.
