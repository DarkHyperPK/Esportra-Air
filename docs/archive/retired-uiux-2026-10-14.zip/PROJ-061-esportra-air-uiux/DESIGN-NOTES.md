# PROJ-061 — Esportra Air UI / UX grounded in the system

13 October 2026 · 33 static frames · Independently creatively approved for static design.

Open [index.html](index.html) to view the gallery or [esportra-air-screen-designs.pdf](esportra-air-screen-designs.pdf) for the selectable-text PDF. Full PNGs are in `png/`. Editable source is `components.js`, `web.js`, `desktop.js`, `screens.js`, `screens.css` and `project.css`.

This is the revised pack requested after the user identified PROJ-061 and asked for Obsidian context. It supersedes the earlier generic Air pack as the design reference for this task. It contains proposed UI designs, not runtime implementation. The existing PROJ-061 proposal remains awaiting approval; no commits, pushes, acceptance or deployment are claimed.

## What changed after retrieving context

Read through Obsidian MCP: Codex-Start, Claude-Start, Current-Work, Memory-Protocol, AI-Company-Memory, Air, Frontend, Broadcast-Production, Air-Code-Map, Conflicts-and-Unknowns, project/session indexes, and the 13 October PROJ-061 Broadcast UX handoff. Reconciled those notes with the live frontend project record, its clarifications and creative contract, then independently audited current backend/frontend/Air contracts.

The resulting system model is:

- Main Esportra web plans shows and administers organization membership, tournament context, rundown, sponsors and reports.
- Platform backend authorizes and synchronizes show/node data. Web generates temporary pairing codes.
- Air desktop redeems pairing codes and keeps the node credential on the computer. The production node runs local HUD, OBS integration and the show runner.
- Capture-only Air on the observer PC obtains game events through a separate ow-electron child and sends them over LAN. It has no producer navigation.
- OBS owns video recording and streaming. Air does not become a video transport or encoder.

Current source has materially fewer web capabilities than the old creative references imply. The design now shows those limits instead of inventing data:

| Question | Verified evidence | Treatment |
|---|---|---|
| Can web show node health? | GET nodes returns lastSeenAt, name and capabilities; heartbeat writes only last_seen_at. | Show recent heartbeat age. Do not show local OBS, HUD, GEP or mode fields as platform telemetry. |
| Does web have live scores or program frames? | No broadcast-home contract for those fields; frames are local Electron IPC. | Unavailable preview / score treatment. No fabricated latency, next cue or countdown. |
| Can this code be confirmed as paired on web? | Claim association is private; no code-specific status event or endpoint. | Refresh the node list, identify the newly registered computer, and check its heartbeat. Registration and connection remain separate. |
| What can invited roles control? | Five valid IDs; all active crew join the same show-state group. No role-specific remote OBS command endpoint found. | Joined / Pending states, shared show feed, job descriptions that do not grant extra commands. |
| Can web send remote Hold / Take today? | Hook exists, mapped backend command endpoint and Air inbound handler were not found. | No new remote command promises in home or crew. Local controls remain in desktop. |
| Are home metrics and alerts real? | Clarifications exclude Hands-Free and Sponsor On Air; alerts may be absent. | “—” for unavailable metrics; honest empty alerts. Per-show sponsor proof does not establish the home metric. |
| Does OBS discover itself? | Desktop connect requires host, port, password. | Explicit instructions to connect locally. Password is entered in desktop only. |
| Does scene creation replace scenes? | Local builder creates five ESA_ scene concepts, skips existing names, adds supplied local sources only to new scenes. | Explain preservation and inspection. No web scene-build command. |
| Is recorded-match rehearsal a production feature? | Simulator is development-only. | Manual local graphics check; no simulation button or “nothing goes live” guarantee. |
| Is the default hold five seconds? | ShowRunner default is 30 seconds. | Example uses 00:30; implementation must display configured duration. |
| Does title editing work now? | General PATCH endpoint is absent; PROJ-061 proposes it and live-title 409. | Render the proposed edit, saving intent and locked-live state; record the dependency. |

Precise source citations and the independent CTO return are in [review/source-audit.md](review/source-audit.md), with [creative review](review/creative-review.md) and [design brief](review/design-brief.md) alongside it. Originals stay in the canonical owner: `D:/frag-and-book-main/.claude/company/projects/PROJ-061/`.

## Direction and flows

Continue the established Command Console direction for expert administration, Broadcast focus anatomy for pairing/onboarding and Control Room composition for producer. Square surfaces, full viewport, Poppins/Inter/JetBrains, white actions, semantic states. Rose is used for live/code/progress intent; pairing progress is neutral so the code owns the cue. Static delivery contains no decorative motion.

The preparation wizard is deliberately separate from the existing persisted-data show setup checklist. It has all nine task compositions:

1. Link an organization tournament and name the show.
2. Prepare existing match slots, match codes and rundown segments.
3. Open an installed Air app. The installer action stays unavailable until a verified release link exists.
4. Generate a code on web; enter it in Air; inspect the registered node.
5. Configure OBS locally using host, port and password.
6. Build or inspect local OBS scenes, preserving existing names.
7. Verify game capture on the same PC or a separate capture-only observer.
8. Inspect local graphics and the OBS preview before changing program.
9. Choose a supported crew role before generating an invitation.

The canonical contract's excluded “choose the look” and unsupported recorded rehearsal were replaced with existing rundown preparation and local graphics inspection. These are explicitly recorded design corrections, not silent changes to the canonical proposal. Manual desktop checks record preparation; they do not certify ongoing health. Completed steps remain available for review. Exact progress persistence and backend completion wiring remain implementation work.

No crew browser-source URLs, co-stream links, cloud relay, phone remote, source-key rotation, source pack email, HUD gallery or rundown/live-monitor redesign is added. The mobile frames are responsive web compositions.

## Screens and evidence mapping

| Screen / state | User task | Data / implementation boundary |
|---|---|---|
| web-01 Home | See live shows and the next scheduled show | Show-list aggregates; proposed home endpoint; truthful unavailable telemetry. |
| web-02 Node pairing | Obtain a temporary code | Existing `/nodes/codes`; owner authorization, expiry and required rate-limit fix. |
| web-03 Code expired | Generate a replacement | Expiry comes from server expiresAt; no expired-code reuse. |
| web-04 Node detected | Confirm the computer identity | Existing node list; no code-correlated claim guarantee. |
| web-05 Show setup | Resolve missing saved configuration | Existing checklist; fix title/tournament CTAs rather than self-navigation. |
| web-06 Tournament picker | Search organization tournaments | Existing `/api/organizations/{orgId}/tournaments`; proposed PATCH must atomically verify ownership. |
| web-07 Title edit | Save title inline | Proposed PATCH; preserve dialog and text on save failure. |
| web-08 Live title locked | Understand why editing is blocked | Proposed live-title 409; header and sidebar both show Live. |
| web-09 Wizard step 1 | Create / link show context | Existing create plus proposed update as needed; if linking fails, retain created show and retry without duplication. |
| web-09a Step 2 | Prepare existing rundown | Existing surfaces; no new editor implementation. |
| web-09b Step 3 | Install / open Air | No unverified package size or working download claim. |
| web-10 Step 4 | Generate code inside wizard | Web displays; desktop redeems. |
| web-11 Step 4 registered state | Confirm newly seen Booth B | One wizard continuation action, separate heartbeat evidence. |
| web-11a Step 5 | Configure OBS | Local connection, credentials stay desktop. |
| web-11b Step 6 | Check scenes | Actual local builder semantics, user preparation acknowledgment. |
| web-11c Step 7 | Set up capture | Real modes/relay; restart after mode change; video stays separate. |
| web-11d Step 8 | Inspect graphics | Manual local verification, no development simulator in product. |
| web-11e Step 9 | Invite crew | Role selection and owner-only invitation administration. |
| web-12 Completion | Review preparation | 9/9 preparation does not certify live readiness. |
| web-13 Crew | Understand membership, role and visibility | Five valid role IDs, owner-only list, Joined / Pending. |
| web-14 Role selection | Choose before generating link | producer / observer / monitor / technical_director / replay_operator. |
| web-15 Invitation ready | Copy the temporary link | One-use, 72h expiry, sign-in, transient token display; placeholder only. |
| desktop-01 Pair | Redeem the code | Existing desktop main exchange and keychain boundary. |
| desktop-02 Readiness | Resolve the failing local check | Local status; capture attention is shown before automation. |
| desktop-03 Producer | Operate local scenes and runner | Actual F1–F8 meanings, local program/preview, configured hold. |
| desktop-04 Disconnected | Recover OBS before switching | No Signal; unavailable controls. Reconnect policy must follow local controller, not guessed manual-only resume. |
| desktop-05 Capture-only | Verify observer event relay | Separate navigation; no producer controls. No packets means no measured latency. |
| desktop-06 Outputs | Recognize missing output records | Current local status does not provide a populated output list; no fake URL/copy data. |
| system-01 Architecture | Understand ownership and transport | Verified system map; documentation, not a product route. |
| system-02 UI states | Implement recovery and limits | Generating, expired, unavailable, blocked, permission and disconnection intent. |
| mobile-01 Home | Oversee shows on a phone | Recomposition, not a phone-remote feature. |
| mobile-02 Pair step | Read code on a phone | One rose code cue, neutral progress, explicit direction. |
| mobile-03 Tournament picker | Select an organization tournament | Reflowed modal with no horizontally overflowing desktop table. |

Every name, score, event, time, pairing code, node address and invitation shown here is an illustrative fixture. No real credential, customer identity, invitation, node registration or live operation was produced. Existing overlay art illustrates desktop frame geometry only; it is not live video.

## Verification and review

- Independent CTO audited current source and identified the data/permission limits above.
- Independent Creative Lead inspected the pack, requested revisions, and approved the final 33-frame static pack after focused recheck. Rubric 23/24; motion N/A; no zeros; first four criteria 2 each. Remaining nonblocking concern: small mobile labels and runtime accessibility still need an implementation pass.
- Chromium exported 33 PNG frames with no page errors, broken images, horizontal overflow or clipped main content at the exported dimensions. `layout-checks.json` records measurements.
- PDF checked with PyMuPDF: 33 pages, selectable text on every page, 30 wide pages and three mobile pages; no missing page. Selected producer and phone-dialog pages were rasterized for visual comparison.
- Wide review canvas is 1440 × 1200; phone is 390 × 1320. Shorter windows will require scrolling and sticky controls during implementation; these artifacts do not establish minimum app dimensions.
- Gallery links, local assets and export source are included. Re-export with `node design/PROJ-061-system-grounded/export.cjs` from Air. It uses installed Playwright from the frontend checkout (or a local Playwright module if available).

No runtime app tests, production build, live-device usability or deployed behavior are claimed. The HTML is editable presentation source, not React component implementation. Functional keyboard flow, screen readers, reduced motion and error-state bindings must be verified when implementation is authorized.

## Canonical follow-up

The owning project contains focused context, evidence audit, revised brief, independent review and a dated design handoff. Obsidian consolidation records this pack as designed/export-verified/creatively-approved only. Proposal approval, full project QA, CEO acceptance and deployment remain separate.
