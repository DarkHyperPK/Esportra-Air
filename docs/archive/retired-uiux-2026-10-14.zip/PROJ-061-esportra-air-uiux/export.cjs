const fs = require('node:fs');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
let playwright;
try { playwright = require('playwright'); }
catch { playwright = require('D:/frag-and-book-main/node_modules/playwright'); }

const root = __dirname;
const url = pathToFileURL(path.join(root, 'screen.html')).href;

function galleryMarkup(screens) {
  const items = screens.map(s => `<a class="item ${s.type}" href="png/${s.id}.png"><div class="thumb"><img src="png/${s.id}.png" alt="${s.name}"></div><div class="copy"><span>${s.type === 'desktop' ? 'DESKTOP APP' : s.type.toUpperCase()}</span><h2>${s.name}</h2><p>${s.summary}</p></div></a>`).join('');
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Esportra Air — UI / UX screen designs</title><style>@font-face{font-family:Poppins;src:url('assets/Poppins-Bold.ttf')}*{box-sizing:border-box}body{margin:0;background:#09090b;color:#fafafa;font:14px/1.6 'Segoe UI',Arial}a{color:inherit;text-decoration:none}header{padding:42px 40px 30px;border-bottom:1px solid #333;display:flex;justify-content:space-between;align-items:center}h1,h2{font-family:Poppins;margin:0}h1{font-size:32px;letter-spacing:-1px}h2{font-size:16px;margin-top:4px}p{color:#a1a1aa;margin:8px 0 0}header p{font-size:14px}header a{border:1px solid #555;padding:10px 16px;margin-left:8px;font-size:12px}.brand{display:flex;align-items:center;gap:10px;margin-bottom:16px;font-size:13px;color:#a1a1aa}.brand img{width:24px}.section{padding:28px 40px 10px;color:#a1a1aa;font-size:12px}.grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:24px;padding:16px 40px 40px}.item{border:1px solid #303036;background:#111114}.item:focus-visible{outline:2px solid white;outline-offset:4px}.thumb{aspect-ratio:1.5;overflow:hidden;background:#151519;border-bottom:1px solid #303036;display:flex;justify-content:center}.thumb img{width:100%;height:100%;object-fit:contain}.mobile .thumb img{width:auto}.copy{padding:16px 18px}.copy span{font:10px monospace;letter-spacing:1px;color:#a1a1aa}.copy p{font-size:12px}.foot{padding:0 40px 32px;font-size:12px;color:#a1a1aa}.contact header{padding:26px 32px 24px}.contact header h1{font-size:28px}.contact header .brand{margin-bottom:8px}.contact .section{padding:16px 32px 0}.contact .grid{grid-template-columns:repeat(4,minmax(0,1fr));gap:16px;padding:16px 32px 24px}.contact .copy{padding:10px 12px}.contact .copy h2{font-size:13px}.contact .copy p{font-size:10px}.contact .thumb{aspect-ratio:1.5}.contact .foot{padding:0 32px 24px;font-size:11px}@media(max-width:800px){header{display:block;padding:24px}header .links{margin-top:20px}header a{margin:0 8px 0 0;display:inline-block}.grid{grid-template-columns:1fr;padding:20px 24px}.section{padding:20px 24px 0}h1{font-size:26px}}</style></head><body><header><div><div class="brand"><img src="assets/mark-44.png" alt="Esportra">ESPORTRA AIR / SCREEN DESIGN</div><h1>Built around the real Air system.</h1><p>PROJ-061 · Plan on web. Produce locally. Keep the boundaries clear.</p></div><div class="links"><a href="esportra-air-screen-designs.pdf">Design PDF</a><a href="DESIGN-NOTES.md">Design notes</a></div></header><div class="section">13 October 2026 · 22 web screens and states · 6 desktop screens · 2 system boards · 3 mobile web layouts</div><main class="grid">${items}</main><div class="foot">Static mockups for review. All operational values, people, codes and results are illustrative. Click any screen to open its full-resolution PNG.</div></body></html>`;
}

async function exportScreens(page, screens) {
  const results = [];
  for (const s of screens) {
    const viewport = s.type === 'mobile' ? { width:390, height:1320 } : { width:1440, height:1200 };
    await page.setViewportSize(viewport);
    await page.goto(`${url}?screen=${s.id}`);
    await page.evaluate(() => document.fonts.ready);
    await page.screenshot({ path:path.join(root, 'png', `${s.id}.png`), fullPage:true });
    const layout = await page.evaluate(() => {
      const workspace = document.querySelector('.workspace');
      const images = [...document.images].filter(i => !i.complete || !i.naturalWidth).map(i => i.src);
      return { documentWidth:document.documentElement.scrollWidth, viewportWidth:innerWidth,
        contentHeight:workspace.scrollHeight, availableHeight:workspace.clientHeight, brokenImages:images };
    });
    results.push({ screen:s.id, ...layout });
  }
  return results;
}

async function exportPdf(page) {
  await page.setViewportSize({width:1440,height:1200});
  await page.goto(url);
  const pages = await page.evaluate(() => window.AIR_SCREENS.map(s => `<article class="print-sheet ${s.type}" data-screen="${s.id}">${s.render()}</article>`).join(''));
  const printCss = `.print-sheet{width:1440px;height:1200px;position:relative;break-after:page;overflow:hidden;page:wide}.print-sheet .main-grid{height:1138px}.print-sheet.desktop .main-grid{height:1160px}.print-sheet.mobile{width:390px;height:1320px;page:phone}.print-sheet.mobile .main-grid{height:auto}.print-sheet.mobile .mobile-nav{position:absolute}.print-sheet:last-child{break-after:auto}@page wide{size:1440px 1200px;margin:0}@page phone{size:390px 1320px;margin:0}`;
  const printDoc = `<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Esportra Air — screen design pack</title><link rel="stylesheet" href="screens.css"><link rel="stylesheet" href="project.css"><style>${printCss}</style></head><body>${pages}</body></html>`;
  fs.writeFileSync(path.join(root,'print.html'),printDoc);
  await page.goto(pathToFileURL(path.join(root,'print.html')).href);
  await page.evaluate(() => document.fonts.ready);
  await page.pdf({path:path.join(root,'esportra-air-screen-designs.pdf'),printBackground:true,preferCSSPageSize:true,margin:{top:0,bottom:0,left:0,right:0}});
}

async function main() {
  const browser = await playwright.chromium.launch({headless:true});
  const page = await browser.newPage({deviceScaleFactor:1});
  const failures = [];
  page.on('pageerror',e => failures.push(e.message));
  await page.goto(url);
  const screens = await page.evaluate(() => window.AIR_SCREENS.map(({id,name,type,summary}) => ({id,name,type,summary})));
  fs.mkdirSync(path.join(root,'png'),{recursive:true});
  const layout = await exportScreens(page,screens);
  fs.writeFileSync(path.join(root,'index.html'),galleryMarkup(screens));
  await exportPdf(page);
  await page.setViewportSize({width:1600,height:1600});
  await page.goto(pathToFileURL(path.join(root,'index.html')).href);
  await page.evaluate(() => { document.body.classList.add('contact'); document.querySelector('.links').remove(); });
  await page.evaluate(() => document.fonts.ready);
  await page.screenshot({path:path.join(root,'overview.png'),fullPage:true});
  const checks = { generatedAt:'2026-10-13',pageErrors:failures,layout };
  fs.writeFileSync(path.join(root,'layout-checks.json'),JSON.stringify(checks,null,2));
  console.log(JSON.stringify(checks,null,2));
  await browser.close();
}
main().catch(error => {console.error(error);process.exitCode=1;});
