const ICON_PATHS={home:'M3 10l9-7 9 7v10H3z M9 20v-7h6v7',shows:'M3 5h18v13H3z M8 21h8 M12 18v3',list:'M7 5h14 M7 12h14 M7 19h14 M3 5h.1 M3 12h.1 M3 19h.1',monitor:'M3 5h18v13H3z M7 21h10 M12 18v3',crew:'M16 21v-3c0-3-8-3-8 0v3 M12 4a4 4 0 1 0 0 8a4 4 0 1 0 0-8 M19 11a3 3 0 0 1 0 6 M21 21v-2',sponsor:'M5 3h14v18l-7-4-7 4z',report:'M4 3h16v18H4z M8 8h8 M8 12h8 M8 16h5',nodes:'M2 3h8v7H2z M14 3h8v7h-8z M8 16h8v6H8z M6 10v3h12v-3 M12 13v3',check:'M5 12l4 4 10-11',scenes:'M3 3h7v7H3z M14 3h7v7h-7z M3 14h7v7H3z M14 14h7v7h-7z',capture:'M2 12h3l3-7 4 14 4-14 3 7h3',outputs:'M4 20V4h16 M4 4l16 16 M12 20h8v-8',data:'M4 5c0-4 16-4 16 0s-16 4-16 0 M4 5v14c0 4 16 4 16 0V5 M4 12c0 4 16 4 16 0',sync:'M20 7a8 8 0 0 0-14-2L3 8 M3 3v5h5 M4 17a8 8 0 0 0 14 2l3-3 M21 21v-5h-5',settings:'M12 8a4 4 0 1 0 0 8a4 4 0 1 0 0-8 M12 2v3 M12 19v3 M2 12h3 M19 12h3 M5 5l2 2 M17 17l2 2 M5 19l2-2 M17 7l2-2',arrow:'M4 12h16 M14 6l6 6-6 6',copy:'M9 9h12v12H9z M15 9V3H3v12h6',search:'M10 3a7 7 0 1 0 0 14a7 7 0 1 0 0-14 M15 15l6 6',bolt:'M13 2L5 14h7l-1 8 8-13h-7z',pause:'M8 4v16 M16 4v16',play:'M7 3l14 9-14 9z',alert:'M12 3L2 21h20z M12 9v5 M12 17h.1',close:'M5 5l14 14 M19 5L5 19'};
const UI={
  icon:(name,size=18)=>`<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${ICON_PATHS[name]||ICON_PATHS.shows}"/></svg>`,
  button:(text,tone='',attrs='')=>`<button type="button" class="button ${tone}" ${attrs}>${text}</button>`,
  tag:(text,tone='neutral')=>`<span class="tag ${tone}"><i></i>${text}</span>`,
  caption:text=>`<span class="caption">${text}</span>`,
  panel:(title,body,action='')=>`<section class="panel"><header class="panel-head"><h2>${title}</h2>${action}</header><div class="panel-body">${body}</div></section>`,
  intro:(title,text,action='',trail='')=>`${trail?`<div class="crumb">${trail}</div>`:''}<header class="page-head"><div><h1>${title}</h1><p>${text}</p></div><div class="actions">${action}</div></header>`,
  field:(label,value,hint='',extra='')=>`<div class="field"><label>${label}</label><div class="field-value">${value}${extra}</div>${hint?`<p class="hint">${hint}</p>`:''}</div>`,
  preview:(name,options={})=>`<div class="preview ${options.tone||''} ${options.className||''}"><img src="assets/previews/${name}.jpg" alt="Existing Esportra HUD preview artwork">${options.label?`<span class="preview-tally ${options.tone||''}">${options.label}</span>`:''}</div>`,
  notice:(title,text,tone='attention')=>`<div class="notice ${tone}"><div>${UI.icon(tone==='success'?'check':'alert',16)}</div><div><strong>${title}</strong><p>${text}</p></div></div>`,
  table:(headers,rows,widths=[])=>`<table class="table"><colgroup>${headers.map((_,i)=>`<col style="width:${widths[i]||'auto'}">`).join('')}</colgroup><thead><tr>${headers.map(x=>`<th>${x}</th>`).join('')}</tr></thead><tbody>${rows.map(row=>`<tr class="${row.tone||''}">${(row.cells||row).map(c=>`<td>${c}</td>`).join('')}</tr>`).join('')}</tbody></table>`,
  tabs:(names,selected)=>`<div class="tabs">${names.map(x=>`<span class="tab ${x===selected?'selected':''}">${x}</span>`).join('')}</div>`,
  key:key=>`<kbd>${key}</kbd>`,
  crest:(text,tone='a')=>`<span class="crest ${tone}">${text}</span>`,
  separator:'<div class="spacer"></div>',
  pairCode:()=>'<div class="pair-code">QK74<span>8D3M</span></div>',
  identity:(name,meta,initials)=>`<div class="identity"><span class="avatar">${initials}</span><div><strong>${name}</strong><small>${meta}</small></div></div>`,
  row:(name,meta,end='')=>`<div class="data-row"><div><strong>${name}</strong><p>${meta}</p></div><div>${end}</div></div>`,
  metric:(label,value,detail='')=>`<div class="metric"><span class="caption">${label}</span><strong>${value}</strong><p>${detail}</p></div>`
};
const WEB_NAV=[['home','Home'],['shows','Shows'],['list','Rundown'],['monitor','Monitor'],['crew','Crew'],['sponsor','Sponsors'],['report','Reports'],['nodes','Production nodes'],['check','Get started']];
const DESK_NAV=[['monitor','Console'],['check','Readiness'],['scenes','Scenes'],['capture','Capture'],['outputs','Outputs'],['data','Fix data'],['sync','Sync']];

UI.web=(active,content,options={})=>{
  const nav=WEB_NAV.map(([icon,name],i)=>`${i===7?'<div class="nav-caption">Setup</div>':''}<div class="nav-item ${name===active?'selected':''}">${UI.icon(icon,17)}<span>${name}</span>${name==='Monitor'&&options.target?'<span class="nav-count">2</span>':''}</div>`).join('');
  return `<div class="web-top"><div class="brand"><img src="assets/mark.png" alt="Esportra"><b>ESPORTRA</b><span>Air</span></div><div class="platform-nav"><span>Tournaments</span><span>Teams</span><span class="selected">Broadcast</span></div><div class="top-end"><span>Arena production</span><span class="avatar">AP</span></div></div><div class="web-frame"><aside class="web-rail"><div class="nav-caption">Broadcast</div>${nav}<div class="rail-bottom"><span class="caption">Arena production</span><p>Organization workspace</p><div class="small muted">${UI.icon('settings',14)} Workspace settings</div></div></aside><main class="web-main">${content}</main></div>`;
};
UI.desktop=(active,content,options={})=>{
  const ribbon=options.ribbon||`${UI.tag('HUD running','success')}${UI.tag('Capture receiving','success')}${UI.tag('OBS connected','success')}${UI.tag('Platform synced','neutral')}<span class="ribbon-time">19:42:07 PKT</span>`;
  const nav=DESK_NAV.map(([icon,name])=>`<div class="desk-nav ${name===active?'selected':''}">${UI.icon(icon,18)}<span>${name}</span></div>`).join('');
  return `<div class="desk-top"><div class="brand"><img src="assets/mark.png" alt="Esportra"><b>ESPORTRA AIR</b><span>Studio PC / Esportra Invitational / Grand final</span></div><div class="window-controls">− &nbsp; □ &nbsp; ×</div></div><div class="desk-frame"><aside class="desk-rail">${nav}<div class="desk-settings">${UI.icon('settings',18)}</div></aside><div class="desk-work"><div class="status-ribbon">${ribbon}</div><main class="desk-main ${options.className||''}">${content}</main>${options.footer?`<div class="desk-data-foot">${options.footer}</div>`:''}</div></div>`;
};
UI.modal=(base,title,subtitle,body,buttons)=>`${base}<div class="scrim"></div><section class="modal"><header><div><h2>${title}</h2><p>${subtitle}</p></div>${UI.icon('close',18)}</header><div class="modal-body">${body}</div><footer>${buttons}</footer></section>`;
UI.drawer=(base,title,subtitle,body,buttons)=>`${base}<div class="drawer-scrim"></div><aside class="drawer"><header><div><h2>${title}</h2><p>${subtitle}</p></div>${UI.icon('close',18)}</header><div class="drawer-body">${body}</div><footer>${buttons}</footer></aside>`;
window.UI=UI;
