# Esportra Air — Control Room V3

13 October 2026 · PROJ-061 · Static UI/UX design deliverable.

## What changed

The user prefers the composition and system expression of `D:/Esportra-Air/screens/` and authorized a broad creative revision. V3 restores a compact production rail, status ribbon, preview/program bridge, runner spine, graphics bench, asymmetric web desks and machine-specific observer utility. The previous 33-frame pack was too sparse and over-explained the engineering boundaries inside the product UI. Original screenshots and both older packs remain preserved.

66 purposeful frames: **32 web, 24 desktop, 7 phone web, 3 system boards**. The pack includes every preparation step, the configuration handoff, restricted crew access, OBS loss, pairing expiry, explicit operator pause, local correction confirmation, offline continuation and target reconciliation. Eight main layout families create variety around the actual task instead of repeating a dashboard card grid.

## Open and edit

- `index.html`: static screen gallery with surface filters, full-resolution PNG links and dependency notes.
- `esportra-air-control-room-v3.pdf`: one frame per page, with classifications and source/dependency captions outside the product composition.
- `screen.html?screen=w01-home`: editable local frame renderer. Controls are visual mockups; they do not invoke services.
- `shared.js/css`, `web.js/css`, `desktop.js/css`, `boards.js/css`, `screens.js`: native editable source. No application components were changed.
- `manifest.json`: complete screen register, scope classifications and dependencies.
- `png/`: 66 product-only PNGs. The classification travels in the gallery, manifest and PDF; consult it before using an isolated PNG as an implementation reference.
- `review/`: contact sheets and independent reviews. `layout-checks.json` records export verification.

To regenerate on this workstation, run `node export.cjs`. Playwright is resolved from the existing frontend installation at `D:/frag-and-book-main/node_modules/playwright`; offline bundled fonts and artwork render from this directory. This exporter is a design tool, not an Air runtime build.

## Screen plan and journeys

**Web:** broadcast desk → show ledger → create/link/edit → show workspace → nine preparation steps → pairing and node identity → crew invitation/membership → sponsors → rundown → reports/proof/chapters. Show configuration sends title/matches/casters/sponsors; the UI tells users to verify the local machine. Ending a show changes the platform record and does not stop OBS.

**Production workstation:** choose role → pair → local readiness → OBS connection drawer → build missing scene names → verify in OBS → preview/Take/program console → held cue or operator pause → graphics catalogue → local output preparation → diagnostics → Fix Data confirmation → offline continuation. OBS credentials are kept in the connection drawer. Keyboard intent follows current bindings: F1 Holding, F2 Gameplay, F3 Fullscreen, F4 Replay, F5 Casters, F6 replay buffer, F7 hold, F8 take active segment.

**Observer workstation:** compact 560 × 380 capture utility over a desktop/game context. This machine sends game events over LAN. Its basic source-backed view shows activity and relay consumers; richer packet/recovery information is explicitly a product target. Producer navigation and controls are absent from the observer utility.

**Phone web:** plan/review, keep pairing code beside a workstation, check registered nodes, follow preparation, review reports and see a proposed self-assignment brief. It is not a phone remote for OBS.

**System atlas:** ownership and transports; failure/remaining capability/recovery matrix; typography, palette, focus, component states, touch sizing and motion intent.

## Classification and contract boundaries

**Source-backed** means the design uses existing underlying primitives. It does not certify that this exact composition, every field combination, or live integration has shipped. **PROJ-061 proposed** identifies project additions and related proposed workflow views. **Product target** requires additional contracts. No implementation approval is implied by creating mockups.

| Area | Existing evidence | Additional work required |
|---|---|---|
| Home, show editing, nine-step navigation | Existing list/detail/create, persisted checklist | Proposed aggregate, atomic title/tournament PATCH, actionable wizard. Live title changes need server 409. |
| Pairing | Web `/nodes/codes` returns eight-character code/expiresAt; desktop `/nodes/pair` redeems, stores token in keychain | No code-correlated web claim event exists. Refresh directory; do not show an invented “claimed” event. |
| Node directory | Backend ID/name/capabilities/isActive/lastSeenAt | Rich web health needs a new telemetry schema/transport/auth. Registration, heartbeat and live hub connection are separate. |
| Crew | Role-only invitation creation, one-time token, 72-hour TTL, authenticated acceptance, owner-only list/revoke/remove | No email-delivery promise. Pre-acceptance metadata and self-assignment view need authorized endpoints. Result permission is separate; role does not grant remote OBS controls. |
| Rundown | Web stores planning type/title/duration/status/order/notes; source types include match/break/pre_show/post_show/sponsor_slot/custom | ShowConfig omits rundown/rules; Air handler applies HUD, not runner. Publication, condition editor and application acknowledgment need contracts. Scene names and web planning types are separate. |
| Local producer | OBS screenshot loop supplies local PVW/PGM stills, scene tally/take, health, local runner | PNGs use existing catalogue artwork, not captured frames. A locally loaded rundown is assumed for console scenarios. No web video relay. |
| Scene builder | Creates missing named ESA scenes and browser URL sources, skips existing names | Does not create game-capture/caster-camera/replay-video sources. Target tree/property inspector requires enumeration/mapping contracts. Verify composition in OBS. |
| Outputs | Local overlay catalogue and copy-URL primitive | Current status omits output registry; add/regenerate are stubs. Target per-output registry/connection/render/last-seen needs implementation. No key regeneration promise. |
| Capture | `gepActive`, local relay/listening/consumerCount and hub connection | Renderer expects absent packet/latency/match/production-node fields. F9/F10 pause/sending feedback is local UI only; it is omitted from source-backed screens. Rich diagnostics require transport. |
| Fix Data | IPC patches local HUD and queues correction record | Correction is top-level while generic drain reads entry.data and uses a disallowed NodeEvent type. Typed correction endpoint is not called by current Air drain. No server or bracket acknowledgment can be claimed. |
| Offline queue/conflict | Local queue/runtime primitives and backend result mechanisms | Target inspection requires introspection IPC, typed destinations, acknowledgments and explicit result authorization. Reconnecting cannot be labeled delivered. |
| Reports/proof/VOD | Existing result sources, correction count, sponsor aggregates/slot breakdown, incomplete counts and segment offsets | No fabricated manual proof-entry endpoint, audience/revenue KPI, screenshot evidence or cloud video player. Recording alignment is manual. |

The rich web monitor is read-only and explicitly a product target. Phone remote, crew browser-source keys, cloud video relay, HUD editor and look-pack selector remain outside this work.

## Why there is Valorant artwork in assets

`assets/previews/` contains selected **existing JPG previews only**. They show what a local graphic could look like in the console/catalogue; they are not a second HUD or GEP implementation. Their original sample team/map labels are retained and may differ from the NOVA/ATLAS/Ascent planning fixture. No preview is evidence that a stream ran or a sponsor appeared. Runtime HUD, overlays and game capture remain in their existing folders.

`assets/mark.png` and bundled fonts support offline design rendering. Team shields, sponsor wordmarks and all values are fictional design fixtures. No real invitations, pairing codes or credentials are present.

## Visual and interaction intent

Wide screens are 1440 × 960. Web uses a 208px planning rail and 52px global bar; production uses a 70px rail, 32px titlebar and 44px status ribbon. Observer has its own small utility. Phone width is 390px with independently recomposed content and at least 44px primary targets; varying frame heights show the complete page above its fixed navigation.

Poppins creates the human headline, Inter carries interface text, JetBrains Mono carries data. Square stage-black panels retain Esportra’s broadcast identity. White focuses the primary decision; rose marks program/live; amber marks preview/waiting; emerald confirms; failure red stays separate. State is written in text as well as color.

One primary task per panel. Configuration credentials live in a drawer; destructive local display changes have a consequence-specific confirmation. Operator pause remains explicit through reconnect; OBS-caused pause may resume on OBS recovery. Local work remains distinguishable from server records.

Motion is specified, not implemented: 150ms press feedback; drawer 180ms enter/110ms exit, cubic-bezier(.2,0,0,1); short 600ms confirmation. No looping animation beside program. Reduced motion uses instant state changes. Production accessibility, semantic input widgets, keyboard focus management, reader announcements, touch on physical devices and real responsive behavior remain runtime verification work.

## Evidence and scope

Coordinator retrieved Obsidian startup/product/domain/project memory through MCP, audited current repositories, and supplied focused company context. Creative Lead approved direction before composition; a UI/UX specialist independently audited the flow graph and authored the desktop module. Final creative review and artifact QA are independent of authors.

Source basis: frontend `ce8461a4`, Air `3ad48fe`, backend `2acd03f`; source references include `BroadcastCrewEndpoints.cs`, `BroadcastNodeEndpoints.cs`, `BroadcastShowEndpoints.cs`, `src/types/broadcast.ts`, `useBroadcastCrew.ts`, `useBroadcastShowSegments.ts`, `BroadcastSponsorProofPage.tsx`, Air `main.js`, `obs-controller.js`, `show-runner.js`, `hub-client.js`, `fix-data.js` and capture renderer. Earlier memory describing Air as a simple stub/manual-only app is historical.

Parent PROJ-061 proposal remains **AWAITING_CEO_APPROVAL**. This pack is static design work only; no runtime implementation, live testing, project acceptance, commit, push or deployment is claimed.

## Subsequent source repair

After these source-audit snapshots and static exports, the user separately authorized a focused Air code audit. Queue durability/acknowledgment, typed correction delivery, hub URL/startup retry, correction validation and capture status were locally repaired/tested (23 tests; renderer build passes). See `../../docs/audits/2026-10-13-core-reliability.md`. Earlier gap descriptions above describe the pre-repair source evidence; they remain relevant history, not a claim that the repaired drain is still absent. No full PROJ-061 implementation, bracket-overwrite behavior or live integration certification was added.
