window.AIR_SCREENS=[...(window.WEB_SCREENS||[]),...(window.DESKTOP_SCREENS||[]).map(s=>({...s,type:'desktop'})),...(window.BOARD_SCREENS||[])];
const selected=window.AIR_SCREENS.find(s=>s.id===new URLSearchParams(location.search).get('screen'))||window.AIR_SCREENS[0];
if(selected){document.body.className=selected.type;document.body.dataset.screen=selected.id;document.getElementById('app').innerHTML=selected.render();document.title=`${selected.name} · Esportra Air V3`;}
